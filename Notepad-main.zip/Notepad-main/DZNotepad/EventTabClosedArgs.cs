﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DZNotepad
{
    public class EventTabClosedArgs
    {
        public bool PreventDefault = false;
    }
}
